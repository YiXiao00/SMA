package com.smarthome.sso.web.constants;

/**
 *  Last modify: 181202
 * */

public enum ServiceResult {

    SERVICE_NONE,

    SERVICE_SUCCESS,

    SERVICE_FAIL,

    SERVICE_NOTFOUND,

    SERVICE_ERROR

}
