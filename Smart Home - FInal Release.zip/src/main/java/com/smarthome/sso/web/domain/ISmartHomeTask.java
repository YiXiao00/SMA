package com.smarthome.sso.web.domain;

/**
 * Interface for scheduled task(class Task) and property task(class Task2)
 *
 * */

public interface ISmartHomeTask {



}
